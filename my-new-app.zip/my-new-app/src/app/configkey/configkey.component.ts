import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-configkey',
  templateUrl: './configkey.component.html',
  styleUrls: ['./configkey.component.css']
})
export class ConfigkeyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
