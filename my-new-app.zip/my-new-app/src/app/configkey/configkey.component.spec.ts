import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigkeyComponent } from './configkey.component';

describe('ConfigkeyComponent', () => {
  let component: ConfigkeyComponent;
  let fixture: ComponentFixture<ConfigkeyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConfigkeyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigkeyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
