import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-panelright',
  templateUrl: './panelright.component.html',
  styleUrls: ['./panelright.component.css']
})
export class PanelrightComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
