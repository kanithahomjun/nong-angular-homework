import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LeftmenuComponent } from './leftmenu/leftmenu.component';
import { PanelrightComponent } from './panelright/panelright.component';
import { ConfigkeyComponent } from './configkey/configkey.component';

@NgModule({
  declarations: [
    AppComponent,
    LeftmenuComponent,
    PanelrightComponent,
    ConfigkeyComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
